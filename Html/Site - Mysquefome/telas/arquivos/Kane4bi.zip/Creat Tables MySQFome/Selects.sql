sselect avg(valor_entrega) from pedido;

select sum(valor_pedido) from pedido;

select count(id_pedido) from pedido
where QTD_PRODUTOS > 1;

select c.nome, p.valor_pedido from CLIENTE_MSQF c, pedido p
where c.cpf = p.cpf
group by c.nome, p.valor_pedido
having avg(valor_pedido) >10
order by c.nome;

select id_pedido, qtd_produtos, cpf from pedido
where id_pedido between 1 and 10;

select c.nome, c.cpf, p.id_pedido, p.qtd_produtos
from pedido p, cliente_msqf c
where c.cpf= p.cpf;

select nome, cpf from cliente_msqf
where NOME like '%Pedro%'
union
select nome, cpf from cliente_msqf
where nome like '%V%';

select min(valor_entrega), max(valor_pedido)
from pedido;


select nome, cpf from cliente_msqf
where NOME like '%P%'
union all
select nome, cpf from cliente_msqf
where nome like '%V%';

select id_produto from produto
where id_produto >= 1
intersect
select id_pedido from pedido
where id_produto between 5 and 10;

select id_pedido from pedido
where id_pedido between 1 and 10
minus
select id_pedido from pedido
where id_pedido between 1 and 3;
