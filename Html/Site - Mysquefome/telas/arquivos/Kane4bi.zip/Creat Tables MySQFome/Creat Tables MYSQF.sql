-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE Cliente_MSQF (
CPF Number(11) PRIMARY KEY,
CEP Number(8),
Complemento Varchar2(40),
Telefone Number(11),
Email Varchar2(40),
Nome Varchar2(40)
)

CREATE TABLE Restaurante (
CNPJ Number(15) PRIMARY KEY,
CEP Number(8),
Telefone Number(11),
tipo_culinaria Varchar2(40),
nome Varchar2(40),
Complemento Varchar2(40)
)

CREATE TABLE Produto (
id_produto Number(6) PRIMARY KEY,
qtd_estoque Number(10),
valor_produto Number(5),
nome_produto Varchar2(40),
Categoria Varchar2(40),
Descri��o Varchar2(40)
)

CREATE TABLE Pedido (
id_pedido Number(6) PRIMARY KEY,
valor_entrega Number(5),
valor_pedido Number(5),
qtd_produtos Number(5),
Data Number(8),
CPF Number(11),
id_produto Number(6),
CNPJ Number(15),
FOREIGN KEY(CPF) REFERENCES Cliente_MSQF (CPF),
FOREIGN KEY(id_produto) REFERENCES Produto (id_produto),
FOREIGN KEY(CNPJ) REFERENCES Restaurante (CNPJ)
)
