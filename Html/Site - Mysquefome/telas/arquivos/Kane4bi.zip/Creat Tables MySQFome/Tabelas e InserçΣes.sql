CREATE TABLE Produto (
id_produto Number(6) PRIMARY KEY,
qtd_estoque Number(10),
valor_produto Number(5),
nome_produto Varchar2(40),
Categoria Varchar2(40),
Descri��o Varchar2(40)
);

insert into Produto values ( 1, 50, 35, 'X-Salada', 'Hamburgueria', 'Muito Tomate');
insert into Produto values ( 2, 10, 25.20, 'X-Burguer', 'Hamburgueria', '2 Hamburguers');
insert into Produto values ( 3, 100, 25, 'X-Calabresa', 'Hamburgueria', 'Picante, com Cebola');
insert into Produto values ( 4, 80, 23, 'X-Cheese', 'Hamburgueria', 'Muito Queijo');
insert into Produto values ( 5, 44, 21, 'X-Bacon', 'Hamburgueria', 'Bacon em Tiras');
insert into Produto values ( 6, 33, 30, 'X-Tudo', 'Hamburgueria', 'Tem de Tudo');
insert into Produto values ( 7, 27, 44, 'X-Bagun�a', 'Hamburgueria', 'Frango Temperado');
insert into Produto values ( 8, 45, 18, 'Pizza de Frango', 'Pizzaria', 'Frango com Catupiry');
insert into Produto values ( 9, 79, 21, 'Pizza de Calabresa', 'Pizzaria', 'Calabresa com Cebola');
insert into Produto values ( 10, 58, 20, 'X-Frango', 'Hamburgueria', 'Frango Desfiado');
insert into Produto values ( 11, 88, 20, 'Pizza de Strogonoff', 'Pizzaria', 'Strogonoff de Carne');
insert into Produto values ( 12, 49, 25, 'Pizza de Bacon', 'Pizzaria', 'Bacon Triturado');
insert into Produto values ( 13, 22, 25, 'X-Staker 3.5', 'Hamburgueria', '3 Hamburguers');
insert into Produto values ( 14, 98, 25.50, 'Pizza Quatro Queijos', 'Pizzaria', '4 Queijos');
insert into Produto values ( 15, 16, 24, 'Pizza do Chefe', 'Pizzaria', 'Tem Molho Heinz');

CREATE TABLE Cliente_MSQF (
CPF Number(11) PRIMARY KEY,
CEP Number(8),
Complemento Varchar2(40),
Telefone Number(11),
Email Varchar2(40),
Nome Varchar2(40)
);

insert into Cliente_MSQF values(10585744401, 86084851, 'AP 101', 998847755, 'leonardo.leo@gmail.com','Leonardo Vinicius');
insert into Cliente_MSQF values(87885890902, 86633333, 'AP 102 B01', 884853125, 'l.mattos@gmail.com','Leonardo Mattos');
insert into Cliente_MSQF values(88548470903, 88445155, 'Do Lado do Viscardi', 998517425, 'ramos.pedro@gmail.com','Pedro Ramos');
insert into Cliente_MSQF values(85255790904, 86074888, 'AP 601 B02', 988856645, 'p.carla@gmail.com','Carla Peres');
insert into Cliente_MSQF values(84585790905, 85251488, 'AP 808 B01', 974518865, 'ar.souza@gmail.com','Arlindo Souza');
insert into Cliente_MSQF values(77485790906, 88564812, 'Do lado do Chafaris', 996234185, 'matheus.s@gmail.com','Matheus Silva');
insert into Cliente_MSQF values(66585790907, 86188841, 'Casa Cinza', 995216955, 'higor.g@gmail.com','Higor Gusmao');
insert into Cliente_MSQF values(33685790908, 86552222, 'AP 505 B02', 999997775, 'marcelo.barreto@gmail.com','Marcelo Barreto');
insert into Cliente_MSQF values(48585790909, 86046468, 'Casa Azul e Branca', 996773385, 'b.arantes@gmail.com','Bruno Arantes');
insert into Cliente_MSQF values(87485790910, 86548112, 'Do Lado da Padaria', 995331211, 'fpereira@gmail.com','Francisco Pereira');
insert into Cliente_MSQF values(77885790911, 86669987, 'Casa Verde', 988214466, 'lmanesco@gmail.com','Leandro Manesco');
insert into Cliente_MSQF values(11585790912, 83322514, 'Casa Vermelha', 996155578, 'leonardo.ramalho22@gmail.com','Leonardo Ramalho');
insert into Cliente_MSQF values(69185790913, 86046852, 'AP 404', 985749115, 'v.pedro@gmail.com','Pedro Vitachi');
insert into Cliente_MSQF values(98565790914, 89585585, 'Casa Amarela', 884755545, 'victor.ramos@gmail.com','Victor Ramos');
insert into Cliente_MSQF values(74515790915, 85555555, 'AP 705 B01', 997484466, 'bruns.gustavo@gmail.com','Gustavo Burns');
 

CREATE TABLE Restaurante (
CNPJ Number(15) PRIMARY KEY,
CEP Number(8),
Telefone Number(11),
tipo_culinaria Varchar2(40),
nome Varchar2(40),
Complemento Varchar2(40)
);

insert into Restaurante values(0188474444, 86105551, 33712251, 'Hamburgueria','Hamburgueria das Cavernas', 'Perto da Unifil');
insert into Restaurante values(0280030104, 86141112, 33227555, 'Hamburgueria','Pedros Burguer', 'Proximo a prefeitura');
insert into Restaurante values(0358484155, 86001455, 32225141, 'Hamburgueria','Putz', 'Proximo ao Muffato');
insert into Restaurante values(0488877741, 85656522, 33556698, 'Hamburgueria','Divinos Burguer', 'Perto do Museu');
insert into Restaurante values(0558400044, 86042000, 32228547, 'Hamburgueria','Steak House', 'Esquina com a Rua China');
insert into Restaurante values(0650044455, 86121444, 32655521, 'Hamburgueria','Bilus', 'Do lado do Terminal');
insert into Restaurante values(0758887444, 86554105, 32558477, 'Hamburgueria','Hot Burguer', 'Perto do Shopping');
insert into Restaurante values(0874141158, 86008885, 33669958, 'Pizzaria','Casa da Pizza', 'Perto do Aurora');
insert into Restaurante values(0989996696, 86008455, 32651747, 'Pizzaria','Casa Nova', 'Do lado Da Padaria');
insert into Restaurante values(1058847772, 86585771, 33669985, 'Hamburgueria','Elcios', 'Em Frente a Lumifocus');
insert into Restaurante values(1199632155, 86006661, 33227718, 'Pizzaria','Pizza Hut', 'Esquina com Av.Inglaterra');
insert into Restaurante values(1258887485, 86008447, 32514478, 'Pizzaria','Pizza Mais', 'P');
insert into Restaurante values(1374815155, 85851774, 32213299, 'Hamburgueria','Burns Burguers', 'Perto da Unifil');
insert into Restaurante values(1458845475, 86001144, 996858574, 'Pizzaria','Torre de Piza', 'Perto da Unifil');
insert into Restaurante values(1558474155, 87080445, 32254960, 'Pizzaria','Donovers', 'Perto da Unifil');


CREATE TABLE Pedido (
id_pedido Number(6) PRIMARY KEY,
valor_entrega Number(5),
valor_pedido Number(5),
qtd_produtos Number(5),
Data Number(8),
CPF Number(11),
id_produto Number(6),
CNPJ Number(15),
FOREIGN KEY(CPF) REFERENCES Cliente_MSQF (CPF),
FOREIGN KEY(id_produto) REFERENCES Produto (id_produto),
FOREIGN KEY(CNPJ) REFERENCES Restaurante (CNPJ)
);

insert into Pedido values( 1, 5, 2, 5, 01/12/2017, 10585744401, 1, 0188474444);
insert into Pedido values( 2, 10, 1, 5, 05/01/2017, 87885890902, 2, 0280030104);
insert into Pedido values( 3, 15, 5, 5, 14/01/2017, 88548470903, 3, 0358484155);
insert into Pedido values( 4, 8, 3, 5, 17/12/2017, 85255790904, 4, 0488877741);
insert into Pedido values( 5, 7, 2, 5, 02/12/2017, 84585790905, 5, 0558400044);
insert into Pedido values( 6, 6.50, 5, 5, 30/12/2017, 77485790906, 6, 0650044455);
insert into Pedido values( 7, 12, 2, 5, 21/04/2017, 66585790907, 7, 0758887444);
insert into Pedido values( 8, 5, 2, 5, 19/12/2017, 33685790908, 8, 0874141158);
insert into Pedido values( 9, 4.50, 3, 5, 03/01/2017, 48585790909, 9, 0989996696);
insert into Pedido values( 10, 10, 5, 5, 04/10/2017, 87485790910, 10, 1058847772);
insert into Pedido values( 11, 9, 2, 5, 05/10/2017, 77885790911, 11, 1199632155);
insert into Pedido values( 12, 8.50, 1, 5, 25/11/2017, 11585790912, 12, 1258887485);
insert into Pedido values( 13, 14, 1, 5, 28/12/2017, 69185790913, 13, 1374815155);
insert into Pedido values( 14, 12, 6, 5, 07/07/2017, 98565790914, 14, 1458845475);
insert into Pedido values( 15, 13, 4, 5, 14/05/2017, 74515790915, 15, 1558474155);


