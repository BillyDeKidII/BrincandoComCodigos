--15 tuplas tabela item
insert into Item values (1, 150, 16, 512);
insert into Item values (2, 51, 17, 44);
insert into Item values (3, 10, 18, 22);
insert into Item values (4, 80, 19, 15);
insert into Item values (5, 60, 20, 189);
insert into Item values (6, 141, 21, 101);
insert into Item values (7, 115, 22, 10);
insert into Item values (8, 55, 233, 49);
insert into Item values (9, 49, 58, 120);
insert into Item values (10, 42, 49, 200);
insert into Item values (11, 70, 70, 400);
insert into Item values (12, 112, 45, 150);
insert into Item values (13, 10, 46, 300);
insert into Item values (14, 5, 13, 200);
insert into Item values (15, 2, 17, 100);

--15 tuplas tabela cliente_msqf
insert into Cliente_msqf values (86046460, 01237487891, 1, 'Leonardo Junior',  996754488, 'Rua Salgado Filho, 12', 'leo.junior@gmail.com');
insert into Cliente_msqf values (86046460, 14181741529, 2, 'Benedito Pereira',  996484715, 'Rua Doce Pa1, 13', 'ben.perera@gmail.com');
insert into Cliente_msqf values (86050460, 74845129634, 3, 'Clovis Junior',  996777485, 'Avenida Juscelino Kubtischek, 10058', 'cl.junior@gmail.com');
insert into Cliente_msqf values (86200000, 84848587891, 4, 'Pedro Silverio',  996713548, 'Rua China, 12', 'pedro.silv@gmail.com');
insert into Cliente_msqf values (86046460, 74963207891, 5, 'Anna Colla',  944471588, 'Pedro Gusmao, 499', 'anna.colla@gmail.com');
insert into Cliente_msqf values (86040000, 10585790954, 6, 'Beatriz Goncalves',  996354488, 'Rua Joao Pedro, 914', 'bea.goncal@gmail.com');
insert into Cliente_msqf values (86046460, 88878987891, 7, 'Higor Suguinuma',  88444488, 'Rua Jun Arakawa, 955', 'higor.sug@gmail.com');
insert into Cliente_msqf values (86041511, 10585564644, 8, 'Carlos Gutierrez',  996754488, 'Avenida Rio, 741', 'carlos.gut@gmail.com');
insert into Cliente_msqf values (86047748, 88484851891, 9, 'Victor Aquino',  99684845, 'Pedro Alves, 35', 'victor.aq@gmail.com');
insert into Cliente_msqf values (86046460, 10540187825, 10, 'Pedro Vitachi',  884664488, 'Avenida Inglaterra, 12', 'pedro.v22@gmail.com');
insert into Cliente_msqf values (86046290, 75555784865, 11, 'Cezar Lima',  996300688, 'Rua Alagoas, 312', 'cezar.lima@gmail.com');
insert into Cliente_msqf values (86046490, 34558590965, 12, 'Leonardo Ramallho',  33227533, 'Avenida 10 De Dezembro, 1830', 'le.ramalho@gmail.com');
insert into Cliente_msqf values (86015270, 70050488752, 13, 'Amanda Maciel',  88451942, 'Avenida Rio de Janeiro, 415', 'amanda.ma@gmail.com');
insert into Cliente_msqf values (86046460, 01237487891, 14, 'Rafel Elias',  996748488, 'Avenida Copaza, 44', 'rafael.eli@gmail.com');
insert into Cliente_msqf values (86013898, 10545474899, 15, 'Joao Pedro',  996777777, 'Rua Santo Antonio, 552', 'joao.pedro@gmail.com');

--15 tuplas tabela restaurate
insert into Restaurantes values ('Rua Eurico Humming, 229', 33391255, 'Hamburgueria', 1,  92824202000, 'Hamburgueria das Cavernas');
insert into Restaurantes values ('Avenida Inglaterra, 772', 33396255, 'Hamburgueria', 2,  41323102000, 'Pedros Lanches');
insert into Restaurantes values ('Avenida Juscelino Kubsticheck, 489', 31514855, 'Hamburgueria', 3,  77855202000, 'Putz Burguer');
insert into Restaurantes values ('Avenida Ayrton Senna, 500', 33224255, 'Pizzaria', 4,  44849521611, 'Pizza Mais');
insert into Restaurantes values ('Rua Sao Joao Lacerda, 300', 33391253, 'Pizzaria', 5,  74845199254, 'Pizza Hut');
insert into Restaurantes values ('Avenida Bandeirantes', 33429957, 'Italiana', 6,  71849521458, 'Tompero');
insert into Restaurantes values ('Avenida Pedro III, 889', 37498155, 'Hamburgueria', 7,  74848484444, 'Burgao da Hora');
insert into Restaurantes values ('Avenida Higienolopis, 22', 33284255, 'Mexicana', 8,  51514814774, 'Paletas Burguer');
insert into Restaurantes values ('Rua Salgado Filho, 89', 84511255, 'Hamburgueria', 9,  74848151523, 'Burguer House');
insert into Restaurantes values ('Rua Doce Pai, 778', 33227511, 'Tapiocaria', 10,  85528551454, 'Tapiocao Da Massa');
insert into Restaurantes values ('Avenida Europa, 78', 99678445, 'Cafeteria', 11,  74819526365, 'Coffe House');
insert into Restaurantes values ('Avenida Paulo, 28', 33874255, 'Cafeteria', 12,  77484848585, 'Divinos Caffe');
insert into Restaurantes values ('Rua Alvarenga, 447', 32657484, 'Pizzaria', 13,  88885962314, 'Casa da Pizza');
insert into Restaurantes values ('Rua Jun Arakawa, 955', 33391225, 'Hamburgueria', 14,  12050489024, 'Elcios');
insert into Restaurantes values ('Rua Sergipe, 885', 33226588, 'Japonesa', 15,  99852148748, 'China in Box');

--15 tuplas tabela produtos
insert into Produtos values ( 150, 50, 'X-Salada', 1, 'Hamburgueria', 'Muito Gostoso');
insert into Produtos values ( 50, 10, 'X-Burguer', 2, 'Hamburgueria', 'Bem Salgado');
insert into Produtos values ( 15, 15, 'X-Bacon', 3, 'Hamburgueria', 'Muito Bacon');
insert into Produtos values ( 41, 20, 'X-Frango', 4, 'Hamburgueria', 'Bastante Frango');
insert into Produtos values ( 44, 22, 'X-Queijo', 5, 'Hamburgueria', 'Muito Queijo');
insert into Produtos values ( 52, 50, 'Larica', 6, 'Hamburgueria', 'Muito Gostoso');
insert into Produtos values ( 150, 20, 'X-Badminton', 7, 'Hamburgueria', 'Muito Gostoso');
insert into Produtos values ( 10, 25, 'X-Larica2', 8, 'Hamburgueria', 'Te Enche');
insert into Produtos values ( 85, 32, 'X-TUDO', 9, 'Hamburgueria', 'Bem Grande');
insert into Produtos values (100, 20, 'X-Cretino', 10, 'Hamburgueria', 'Muito Gostoso');
insert into Produtos values ( 50, 50, 'X-Mansao', 11, 'Hamburgueria', 'Muito Sabor');
insert into Produtos values ( 10, 15, 'Dogao', 12, 'Dogs', 'Pra quem Gosta');
insert into Produtos values ( 20, 10, 'Dogao Duplo', 13, 'Dogs', 'Suculento');
insert into Produtos values ( 30, 20, 'Dogao do Patrao', 14, 'Dogs', 'Te enche');
insert into Produtos values ( 45, 25, 'Dog Frango Duplo', 15, 'Dogs', 'Muito Gostoso');

--15 tuplas tabela Pedidos
insert into Pedidos values ( 1, 5, 'X-Bacon', 22/02/2017, 10585790999, 1, 2);
insert into Pedidos values ( 2, 10, 'X-Bacon', 22/05/2017, 55585790999, 2, 1);
insert into Pedidos values ( 3, 15, 'Larica', 10/08/2017, 10598848599, 3, 3);
insert into Pedidos values ( 4, 8, 'Dogao', 11/12/2017, 10585884852, 4, 4);
insert into Pedidos values ( 5, 5, 'X-Queijo', 12/04/2017, 1057480999, 5, 5);
insert into Pedidos values ( 6, 6, 'X-Frango', 11/07/2017, 10548790999, 6, 6);
insert into Pedidos values ( 7, 7, 'X-Salada', 11/02/2017, 10448847999, 7, 7);
insert into Pedidos values ( 8, 8, 'Dogao do Patrao', 17/10/2017, 10566393399, 8, 8);
insert into Pedidos values ( 9, 9, 'X-Cretino', 14/10/2017, 44748193399, 9, 9);
insert into Pedidos values ( 10, 10, 'Dogao do Patrao', 17/10/2017, 41815297399, 10, 10);
insert into Pedidos values ( 11, 11, 'Dogao Duplo', 19/10/2017, 99656393399, 11, 11);
insert into Pedidos values ( 12, 12, 'X-Tudo', 18/11/2017, 10566441599, 12, 12);
insert into Pedidos values ( 13, 13, 'X-Mansao', 11/05/2017, 94152316899, 13, 13);
insert into Pedidos values ( 14, 14, 'X-Mansao', 01/03/2017, 74185214999, 14, 14);
insert into Pedidos values ( 15, 15, 'Dog Frango Duplo', 11/06/2017, 10566748133, 15, 15);

