CREATE TABLE Item (
ID_Item Number(5),
valor Number(7),
ID_produto Number(5),
qtd Number(10),
PRIMARY KEY(ID_Item,ID_produto)
);

select*from item;

CREATE TABLE Cliente_MSQF (
CEP Number(8),
CPF Number(11),
ID_cliente Number(5),
Nome Varchar2(40),
Telefone Number(10),
Endereco  Varchar2(40),
Email Varchar2(20),
PRIMARY KEY(CPF,ID_cliente)
);

select*from cliente_msqf;

CREATE TABLE Restaurantes  (
Endereco Varchar2(40),
Telefone Number(10),
Tipo_de_culinaria Varchar2(40),
ID_restaurante Number(5) PRIMARY KEY,
CNPJ Number(11),
Nome_Fantasia Varchar2(40)
);
select*from restaurantes;

CREATE TABLE Produtos (
qtd_estoque Number(10),
Valor_Produto Number(10),
Nomes_dos_produtos Varchar2(40),
ID_produto Number(5) PRIMARY KEY,
Categoria Varchar2(40),
Descricao Varchar2(40)
);
select*from produtos;

CREATE TABLE Pedidos (
ID_item Number(5) PRIMARY KEY,
valor_entrega Number(5),
Nome_do_produto Varchar2(40),
Data Number(7),
CPF Number(11),
ID_cliente Number(5),
ID_restaurante Number(5)
);
select*from pedidos;

